rdata.filename = '../../../data/DREAM4-10-5.RData'
tbl.ts = read.table ('timeseries.tsv', sep='\t', header=TRUE)
tbl.kd = read.table ('knockdowns.tsv', sep='\t', header=TRUE)
tbl.ko = read.table ('knockouts.tsv', sep='\t', header=TRUE)
tbl.mf = read.table ('multifactorial.tsv', sep='\t', header=TRUE)
tbl.wt = read.table ('wildtype.tsv', sep='\t', header=TRUE)
tbl.dko = read.table ('dualknockouts.tsv', sep='\t', header=T, as.is=T)

tbl.gs = read.table ('goldStandard.tsv', sep='\t', header=T, as.is=T)
save (tbl.wt, tbl.ts, tbl.ko, tbl.kd, tbl.mf, tbl.dko, tbl.gs, file=rdata.filename)

 
